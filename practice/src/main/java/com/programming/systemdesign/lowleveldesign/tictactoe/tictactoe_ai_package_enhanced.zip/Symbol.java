package tictactoe;

public enum Symbol {
    X, O
}