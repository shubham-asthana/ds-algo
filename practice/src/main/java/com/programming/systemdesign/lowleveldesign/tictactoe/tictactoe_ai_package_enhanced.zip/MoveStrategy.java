package tictactoe;

public interface MoveStrategy {
    int[] getMove(Board board);
}